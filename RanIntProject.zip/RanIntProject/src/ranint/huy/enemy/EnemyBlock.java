package ranint.huy.enemy;

import java.util.Random;

public class EnemyBlock {
	Random rand= new Random();
	private int maxEnemies = 6;
	private norEnemy existingEnemies[] = new norEnemy[maxEnemies];
	private int count = 0;
	
	public void addNorEnemies(norEnemy norEnemy) {
		existingEnemies[count] = norEnemy;
		count += 1;
	}
	
	public norEnemy selectEnemy() {
		// HP - DEF - ATT
		norEnemy nor_en1= new norEnemy("Bai kiem tra lien tuc","", 800, 400, 700, 1.0f);
		norEnemy nor_en2= new norEnemy("Len bang tra bai","", 900, 450, 800, 1.0f);
		norEnemy nor_en3= new norEnemy("Bai tap ve nha", "", 700, 400, 700, 1.0f);
		norEnemy nor_en4= new norEnemy("Bai tap nhom", "", 900, 500, 800, 1.0f);
		norEnemy nor_en5= new norEnemy("Thuyet trinh", "", 900, 400, 800, 1.0f);
		norEnemy nor_en6= new norEnemy("bai kiem tra lien tuc 6", "", 500,200,800, 1.0f);
		//norEnemy nor_en7= new norEnemy("nor_en7","bai kiem tra lien tuc 7",500,200,800);
		//norEnemy nor_en8= new norEnemy("nor_en8","bai kiem tra lien tuc 8",500,200,800);
		//norEnemy nor_en9= new norEnemy("nor_en9","bai kiem tra lien tuc 9",500,200,800);
		//norEnemy nor_en10= new norEnemy("nor_en10","bai kiem tra lien tuc 10",500,200,800);
		this.addNorEnemies(nor_en1);
		this.addNorEnemies(nor_en2);
		this.addNorEnemies(nor_en3);
		this.addNorEnemies(nor_en4);
		this.addNorEnemies(nor_en5);
		this.addNorEnemies(nor_en6);
		//this.addNorEnemies(nor_en7);
		//this.addNorEnemies(nor_en8);
		//this.addNorEnemies(nor_en9);
		//this.addNorEnemies(nor_en10);
		return existingEnemies[rand.nextInt(existingEnemies.length)];
	}
}