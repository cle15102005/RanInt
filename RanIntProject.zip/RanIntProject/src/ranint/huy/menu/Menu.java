package ranint.huy.menu;
import java.util.Scanner;

public class Menu {
	private Scanner scanner=new Scanner(System.in);
	
	public String chooseName() {
		System.out.println("Enter your name: ");
		String name=scanner.nextLine();
		System.out.println("Now your character name is:  "+name);
		return name;
		}
	
	public int chooseAge() {
		System.out.println("Enter your age: ");
	    int studentAge = scanner.nextInt();
		System.out.println("Your age is: "+ studentAge);
		return studentAge;
	}
	
	public String chooseSubject() {
		String subjectList[]= {"Calculus 1", "Algebra", "Intro to programing"};
		System.out.println("(+) What subject do you want to choose?\n1. Calculus 1\n2. Algebra\n3. Intro to programing");
		System.out.println("Your choose: ");
		int subj= scanner.nextInt();
		return subjectList[subj-1];
	}
}