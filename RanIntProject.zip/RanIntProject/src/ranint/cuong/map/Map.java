package ranint.cuong.map;
import java.util.Random;
import java.util.Scanner;

import ranint.cuong.battle.BattleBlock;
import ranint.cuong.item.GroceryBlock;
import ranint.cuong.item.Item;
import ranint.cuong.item.ItemBlock;
import ranint.hai.door.DoorBlock;
import ranint.hieu.statistic.Statistic;
import ranint.huy.enemy.Boss;
import ranint.huy.enemy.BossBlock;
import ranint.huy.enemy.EnemyBlock;
import ranint.huy.enemy.norEnemy;
import ranint.huy.menu.Course;
import ranint.linh.buff.Buff;
import ranint.linh.buff.BuffBlock;
import ranint.linh.character.Character;

public class Map {
    private Random rand= new Random();
    private Scanner inp= new Scanner(System.in);
    private Course course;
    private Statistic statistic;
    private double normalPT= 0;
    private double midPT= 0;
    private double finalPT= 0;
    private int charater_location[]= new int[1];
    private int prev_move[] = new int[1]; 
    private int next_move[] = new int[1];
    private Character character;
    public int map[][]= new int[5][5];
    
	public int[][] getMap() {
		return map;
	}

	public int[] getCharater_location() {
		return charater_location;
	}

	public void setCharater_location(int[] charater_location) {
		this.charater_location = charater_location;
	}
	
	public int[] getNext_move() {
		return next_move;
	}

	public void setNext_move(int[] next_move) {
		this.next_move = next_move;
	}
	
	public Map(Course course, Character character) {
		super();
		this.course = course;
		this.character= character;
	}

	public void makeMap(){
		/*1: character location	;	 2: Enemy Block;
		  3: Boss Block			;	 4: Item Block;
		  5: Door Block			;	 6: Buff Block;
		  7: Grocery Block		;	 8: Mid Boss;
		  9: Final Boss;
		 */
		
		setCharacter();
		setEnemy();
		//setBoss();
		setItem();
		setDoor();
		setBuff();
		setGrocery();
		setMidBoss();
		setFinalBoss();
	}
	
	public void showMap() {
		System.out.printf("_______%s_______\n", this.course.getName());
		for(int i= 0; i< 5; i++) {
			for(int j=0; j< 5; j++) {
				if(map[i][j]==0) {
					System.out.printf(" %s ", "_ ");
				}
				else if(map[i][j]==1) {
					System.out.printf(" %s ", "x ");
				}
				else if(map[i][j]==5) {
					System.out.printf(" %s ", "[]");
				}
				else if(map[i][j]==8) {
					System.out.printf(" %s ", "M ");
				}
				else if(map[i][j]==9) {
					System.out.printf(" %s ", "F ");
				}
				else {
					System.out.printf(" %s ", ". ");
				}
			}
			System.out.printf("\n");
		}
    }
	
	public void instruction() {
		System.out.println("INSTRUCTION:");
    	System.out.println("1, How to move: w->up, s->down, a->left, d->right");
    	System.out.println("2, When you finish a scene, you will be asked "
    			+ "\"What do you want to do next?\", your options are:"
    			+ "\n     0 -> show instruction again"
    			+ "\n     1 -> show information"
    			+ "\n     2 -> show your available items"
    			+ "\n     3 -> show your stat"
    			+ "\n     4 -> use your available items"
    			+ "\n     5 -> move");
    	System.out.println("3, In the map appear on the screen, \"x\" is your current location "
    			+ "and \"[]\" is the escape door. "
    			+ "\n   Your task is to reach this door, get out the map and win! "
    			+ "\n============================================================================\n");
	}
	
    public void play(){
    	boolean escapse= false;
    	instruction();    	
    	System.out.println("Press Enter to continue.");
		inp.nextLine();
    	while(!escapse) {
    		this.showMap();
    		System.out.println("What do you want to do next?");
    		String choice = inp.nextLine();
    		switch(choice) {
    		case "0":
    			instruction();
    		case "1":
    			character.showInformation();
    			break;
    		case "2":
    			character.showItems();
    			break;
    		case "3":
    			character.showStat();
    			break;
    		case "4":
    			character.showItems();
    			if (character.getInventory().getIndex() != 0) {
    				System.out.println("What do you want to use? Please enter exactly its name:");
        			String item = inp.nextLine();
        			//System.out.println(item);
        			character.useItem(item);
    			}
    			else {
    				System.out.println("You have no available item in your inventory!");
    			}
    			break;
    		case "5":
    			System.out.printf("Your next move (w, a, s, d): ");
    	    	String move= inp.nextLine();
    	    	prev_move= this.getCharater_location();
    	   		int row= prev_move[0];
    	   		int col= prev_move[1];
    	   		
    	   		//change "row" and "col" to match with the next location
    	    	switch(move) {
    	   		case "w":
    	    		row-=1;
    	    		if (row < 0) {
    	    			row = 0;
    	    		}
    	    		break; 		
    		   	case "a":
    		   		col-=1;
    		   		if (col < 0) {
    		   			col = 0;
    		   		}
    		   		break;
    	    	case "s":
    		    	row+=1;
    		    	if (row > 4) {
    	    			row = 4;
    	    		}
    		    	break;		
    		    case "d":
    		   		col+=1;
    		   		if (col > 4) {
    		   			col = 4;
    		   		}
    		   		break;	
    	    	}
    	    	int next_move[]= {row, col};
    	    	this.setNext_move(next_move);
    	    	
    	    	//which scene that character meet
    	    	switch(map[this.getNext_move()[0]][this.getNext_move()[1]]) {
    	    	case 0:
    	    		// visited, if turn back encounter nothing
    	    		map[this.getCharater_location()[0]][this.getCharater_location()[1]]= 0;
    	        	this.setCharater_location(next_move);
    	    		map[this.getNext_move()[0]][this.getNext_move()[1]]= 1;
    	    		//this.showMap();
    	    		break;
    	    	case 2:
    	    		this.norEnemyCounter();
    	    		if (character.getHP() == 0) {
    	    			escapse = true;
    	    		}
    	    		break;
    	    	//case 3:
    	    	//	this.bossCounter();
    	    	//	if (character.getHP() == 0) {
    	    	//		escapse = true;
    	    	//	}
    	    	//	break;
    	    	case 4:
    	    		this.itemCounter();
    	    		if (character.getHP() == 0) {
    	    			escapse = true;
    	    		}
    	    		break;
    	    	case 5:
    	    		this.doorCounter();
    	    		escapse= true;
    	    		break;
    	    	case 6:
    	    		this.buffCounter();
    	    		if (character.getHP() == 0) {
    	    			escapse = true;
    	    		}
    	    		break;
    	    	case 7:
    	    		this.groceryCounter();
    	    		break;
    	    	case 8:
    	    		midBossCounter();
    	    		if (character.getHP() == 0) {
    	    			escapse = true;
    	    		}
    	    		break;
    	    	case 9:
    	    		finalBossCounter();
    	    		if (character.getHP() == 0) {
    	    			escapse = true;
    	    		}
    	    		break;
    	    	}
    		}
    	}	
    }
     
	public void setCharacter(){
		int r= rand.nextInt(0,5);
		int c= rand.nextInt(0,5);
		map[r][c]= 1;
		
		int temp_location[]= {r,  c};
		this.setCharater_location(temp_location);
	} 
	
	public void setEnemy() {
		int nbEnemies= 0;
		int MAX_ENEMIES= 10;
		while(nbEnemies< MAX_ENEMIES) {
			int r= rand.nextInt(0,5);
			int c= rand.nextInt(0,5);
			if(map[r][c]==0) {
				map[r][c]= 2;
				nbEnemies+=1;
			}
		}
		
	}
	
	public void norEnemyCounter() {
		map[this.getCharater_location()[0]][this.getCharater_location()[1]]= 0;
    	this.setCharater_location(next_move);
		map[this.getNext_move()[0]][this.getNext_move()[1]]= 1;
		BattleBlock bbl= new BattleBlock();
		EnemyBlock eb= new EnemyBlock();
		norEnemy enemy= eb.selectEnemy();
		boolean win= bbl.norBattle(character, enemy);
		
		//add EXP
		if(win) {
			normalPT+= enemy.getPoint();
			System.out.println("Your normal point: " + normalPT);
		}
	}
	
	public void setItem() {
		int nbItems= 0;
		int MAX_ITEMS= 5;
		while(nbItems< MAX_ITEMS) {
			int r= rand.nextInt(0,5);
			int c= rand.nextInt(0,5);
			if(map[r][c]==0) {
				map[r][c]= 4;
				nbItems+=1;
			}
		}
	}
	
	public void itemCounter() {
		map[this.getCharater_location()[0]][this.getCharater_location()[1]]= 0;
    	this.setCharater_location(next_move);
		map[this.getNext_move()[0]][this.getNext_move()[1]]= 1;
		ItemBlock ib= new ItemBlock();
		Item item= ib.selectItem();
		System.out.printf("(+) You are walking, and you see a %s.\n", item.getName());
		character.getInventory().takeOrNot(item, character);
		//character.showStat();
	}
	
	public void setDoor() {
		while(true) {
			int r= rand.nextInt(0,5);
			int c= rand.nextInt(0,5);
			if(map[r][c]==0) {
				map[r][c]= 5;
				break;
			}
		}
	}
	
	public void doorCounter() {
		map[this.getCharater_location()[0]][this.getCharater_location()[1]]= 0;
    	this.setCharater_location(next_move);
		map[this.getNext_move()[0]][this.getNext_move()[1]]= 1;
		System.out.println("____Stage clear____");
		showCoursePoint();
		System.out.println("(?) What do you want to do next?");
		DoorBlock db= new DoorBlock();
	}
	
	public void setBuff() {
		int nbBuffs= 0;
		int MAX_BUFFS= 5;
		while(nbBuffs< MAX_BUFFS) {
			int r= rand.nextInt(0,5);
			int c= rand.nextInt(0,5);
			if(map[r][c]==0) {
				map[r][c]= 6;
				nbBuffs+=1;
			}
		}	
	}
    
	public void buffCounter() {
		map[this.getCharater_location()[0]][this.getCharater_location()[1]]= 0;
    	this.setCharater_location(next_move);
		map[this.getNext_move()[0]][this.getNext_move()[1]]= 1;
		System.out.println("________Buff________");
		BuffBlock bb = new BuffBlock();
		Buff buff= bb.selectBuff();
		System.out.printf("(+) You have encountered something special. That is %s.\n", buff.getBuffName());
		buff.activeBuff(buff, character);
		character.showStat();
	}
	
	public void setGrocery() {
		while(true) {
			int r= rand.nextInt(0,5);
			int c= rand.nextInt(0,5);
			if(map[r][c]==0) {
				map[r][c]= 7;
				break;
			}
		}
	}
	
	public void groceryCounter() {
		map[this.getCharater_location()[0]][this.getCharater_location()[1]]= 0;
    	this.setCharater_location(next_move);
		map[this.getNext_move()[0]][this.getNext_move()[1]]= 1;
		System.out.println("(+) Wao! You saw a grocery nearby.");
		GroceryBlock gb= new GroceryBlock();
		gb.ask(character);
	}
	
	public void setMidBoss() {
		while(true) {
			int r= rand.nextInt(0,5);
			int c= rand.nextInt(0,5);
			if(map[r][c]==0) {
				map[r][c]= 8;
				break;
			}
		}
	}
	
	public void midBossCounter() {
		map[this.getCharater_location()[0]][this.getCharater_location()[1]]= 0;
    	this.setCharater_location(next_move);
		map[this.getNext_move()[0]][this.getNext_move()[1]]= 1;
		BattleBlock bbl= new BattleBlock();
		BossBlock bb= new BossBlock();
		Boss midBoss= bb.selectMidBoss();
		boolean win= bbl.midBossBattle(character, midBoss);
		
		//add EXP
		if(win) {
			midPT= midBoss.getPoint();
		}
	}
	
	public void setFinalBoss() {
		while(true) {
			int r= rand.nextInt(0,5);
			int c= rand.nextInt(0,5);
			if(map[r][c]==0) {
				map[r][c]= 9;
				break;
			}
		}
	}
	
	public void finalBossCounter() {
		map[this.getCharater_location()[0]][this.getCharater_location()[1]]= 0;
    	this.setCharater_location(next_move);
		map[this.getNext_move()[0]][this.getNext_move()[1]]= 1;
		BattleBlock bbl= new BattleBlock();
		BossBlock bb= new BossBlock();
		Boss finalBoss= bb.selectFinalBoss();
		boolean win= bbl.finalBossBattle(character, finalBoss);
		//add EXP
		if(win) {
			finalPT= finalBoss.getPoint();
		}
	}
	
	public void showCoursePoint() {
		double point= statistic.calculatecoursePT(normalPT, midPT, finalPT);
		System.out.println("Your course point is: " + point);
	}
}

